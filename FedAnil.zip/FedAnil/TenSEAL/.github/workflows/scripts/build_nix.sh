#!/bin/sh

# we need to install tenseal in order to build the cpp library
pip install .
