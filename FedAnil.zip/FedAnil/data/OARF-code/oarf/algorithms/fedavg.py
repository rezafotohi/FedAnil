from oarf.algorithms.fedavg_server import FedAvgServer
from oarf.algorithms.fedavg_client import FedAvgClient

__all__ = ['FedAvgServer', 'FedAvgClient']
