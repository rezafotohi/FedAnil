class Module:
    """
    Base class of all multi-inheritance classes
    Used for eating unused parameters
    """
    def __init__(*_, **__):
        pass
