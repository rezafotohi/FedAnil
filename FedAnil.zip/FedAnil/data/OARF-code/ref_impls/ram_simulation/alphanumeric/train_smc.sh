#!/bin/bash

# Secure Multiparty Computation
python train.py --spdz 2>&1 | tee smc.txt