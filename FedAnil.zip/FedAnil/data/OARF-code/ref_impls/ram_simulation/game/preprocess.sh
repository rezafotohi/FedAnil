#!/bin/bash

python sample_steam_interact.py
python align.py
python negative_sample_align_interact.py